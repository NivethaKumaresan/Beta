document.addEventListener('DOMContentLoaded', () => {
    // Initialize Lucide Icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});

// Toggle Mobile Dropdown Navigation Menu
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('hidden');
        mobileMenu.classList.toggle('flex');
    }
}

// Interactive Preview Tabs Switching
function switchTab(tabName) {
    const tabs = ['analytics', 'design', 'code'];

    tabs.forEach(t => {
        const content = document.getElementById(`content-${t}`);
        const tabBtn = document.getElementById(`tab-${t}`);

        if (t === tabName) {
            content?.classList.remove('hidden');
            tabBtn?.classList.add('bg-gradient-to-r', 'from-pink-500', 'to-purple-600', 'text-white', 'shadow');
            tabBtn?.classList.remove('text-slate-400');
        } else {
            content?.classList.add('hidden');
            tabBtn?.classList.remove('bg-gradient-to-r', 'from-pink-500', 'to-purple-600', 'text-white', 'shadow');
            tabBtn?.classList.add('text-slate-400');
        }
    });
}

// Copy Code Snippet Action
function copyCode() {
    const codeElement = document.getElementById('code-snippet');
    const btnText = document.getElementById('copy-btn-text');

    if (codeElement) {
        navigator.clipboard.writeText(codeElement.innerText).then(() => {
            if (btnText) btnText.innerText = 'Copied!';
            triggerNotification('CSS code copied to clipboard!');
            setTimeout(() => {
                if (btnText) btnText.innerText = 'Copy CSS';
            }, 2000);
        });
    }
}

// Dynamic Toast Notification Helper
function triggerNotification(message) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'px-4 py-3 rounded-xl bg-slate-900 border border-pink-500/30 text-white text-xs shadow-lg flex items-center gap-2 transition-all duration-300 opacity-0 translate-y-2';
    toast.innerHTML = `<span class="w-2 h-2 rounded-full bg-pink-500"></span>${message}`;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.remove('opacity-0', 'translate-y-2');
    }, 10);

    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 2500);
}